import { createClient, type Session, type SupabaseClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const supabase: SupabaseClient | null =
  url && anonKey ? createClient(url, anonKey) : null;

export type AdminProfile = {
  id: string;
  name: string | null;
  role: 'user' | 'admin' | 'super_admin';
};

export async function getAdminProfile(session: Session): Promise<AdminProfile> {
  if (!supabase) throw new Error('Supabase is not configured for the admin panel.');
  const { data, error } = await supabase
    .from('profiles')
    .select('id,name,role')
    .eq('id', session.user.id)
    .single();
  if (error) throw error;
  if (!data || !['admin', 'super_admin'].includes(data.role)) {
    throw new Error('This account does not have administrator access.');
  }
  return data as AdminProfile;
}