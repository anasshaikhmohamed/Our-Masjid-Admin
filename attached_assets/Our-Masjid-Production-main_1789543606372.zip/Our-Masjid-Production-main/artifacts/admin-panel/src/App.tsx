import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  Activity,
  AlertTriangle,
  ArrowUpRight,
  Building2,
  Check,
  ChevronRight,
  CircleHelp,
  FileCheck2,
  Filter,
  GalleryHorizontalEnd,
  HeartHandshake,
  LayoutDashboard,
  LibraryBig,
  MapPin,
  Menu,
  PanelLeftClose,
  PanelLeftOpen,
  RefreshCw,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  WalletCards,
  X,
} from 'lucide-react';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import {
  getHealthCheckQueryKey,
  getListPublishedHomeSlidesQueryKey,
  getListPublishedMasjidsQueryKey,
  getListPublishedProjectsQueryKey,
  useHealthCheck,
  useListPublishedHomeSlides,
  useListPublishedMasjids,
  useListPublishedProjects,
} from '@workspace/api-client-react';
import type { HomeSlide, PublicMasjid, PublicProject } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { getAdminProfile, supabase, type AdminProfile } from '@/lib/supabase';

const queryClient = new QueryClient();
const apiKeys = {
  health: getHealthCheckQueryKey(),
  projects: getListPublishedProjectsQueryKey(),
  masjids: getListPublishedMasjidsQueryKey(),
  slides: getListPublishedHomeSlidesQueryKey(),
};

type ProjectRecord = PublicProject & {
  masjid?: { id?: string; name?: string; location?: string; city?: string; is_urgent?: boolean; image_url?: string | null };
};

const navItems = [
  { href: '/', label: 'Overview', icon: LayoutDashboard },
  { href: '/masjids', label: 'Masjids', icon: Building2 },
  { href: '/projects', label: 'Projects', icon: HeartHandshake },
  { href: '/slides', label: 'Home slides', icon: GalleryHorizontalEnd },
];

function cn(...parts: Array<string | false | undefined>) {
  return parts.filter(Boolean).join(' ');
}

function formatMoney(value: number) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value || 0);
}

function SignInScreen({ message, onRetry }: { message?: string; onRetry?: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(message ?? '');
  const client = supabase;

  if (!client) {
    return <div className="flex min-h-[100dvh] items-center justify-center bg-background px-5"><div className="w-full max-w-md rounded-2xl border border-border bg-card p-8 shadow-sm"><ShieldCheck className="text-primary" size={28} /><p className="mt-5 font-mono-ui text-[10px] uppercase tracking-[0.18em] text-primary">Admin access</p><h1 className="mt-2 font-display text-3xl font-semibold">Supabase setup required</h1><p className="mt-3 text-sm leading-relaxed text-muted-foreground">Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY for this admin panel. Public content remains available in the mobile app without exposing this console.</p>{onRetry && <button onClick={onRetry} className="mt-6 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">Check again</button>}</div></div>;
  }

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError('');
    const { error: signInError } = await client.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (signInError) setError(signInError.message);
  };

  return <div className="flex min-h-[100dvh] items-center justify-center bg-background px-5"><form onSubmit={submit} className="w-full max-w-md rounded-2xl border border-border bg-card p-8 shadow-sm"><ShieldCheck className="text-primary" size={28} /><p className="mt-5 font-mono-ui text-[10px] uppercase tracking-[0.18em] text-primary">Trusted workspace</p><h1 className="mt-2 font-display text-3xl font-semibold">Sign in to Our Masjid Admin</h1><p className="mt-3 text-sm leading-relaxed text-muted-foreground">Only Supabase accounts with an admin or super-admin role can access publication tools.</p>{error && <div className="mt-5 rounded-lg border border-destructive/25 bg-destructive/5 p-3 text-sm text-destructive">{error}</div>}<label className="mt-6 block text-xs font-semibold">Email<input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} className="mt-2 h-11 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/30" /></label><label className="mt-4 block text-xs font-semibold">Password<input required type="password" value={password} onChange={(event) => setPassword(event.target.value)} className="mt-2 h-11 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/30" /></label><button disabled={busy} className="mt-6 h-11 w-full rounded-lg bg-primary text-sm font-semibold text-primary-foreground disabled:opacity-60">{busy ? 'Checking access…' : 'Sign in'}</button></form></div>;
}

function AdminGate({ children }: { children: ReactNode }) {
  const [sessionReady, setSessionReady] = useState(false);
  const [profile, setProfile] = useState<AdminProfile | null>(null);
  const [error, setError] = useState('');
  const [, setRefresh] = useState(0);
  const client = supabase;

  useEffect(() => {
    if (!client) {
      setSessionReady(true);
      return;
    }
    let active = true;
    const load = async () => {
      const { data } = await client.auth.getSession();
      if (!active) return;
      if (!data.session) {
        setProfile(null);
        setSessionReady(true);
        return;
      }
      try {
        setProfile(await getAdminProfile(data.session));
        setError('');
      } catch (profileError) {
        setProfile(null);
        setError(profileError instanceof Error ? profileError.message : 'Administrator access denied.');
      } finally {
        setSessionReady(true);
      }
    };
    void load();
    const { data: listener } = client.auth.onAuthStateChange(() => void load());
    return () => {
      active = false;
      listener.subscription.unsubscribe();
    };
  }, []);

  if (!sessionReady) return <div className="flex min-h-[100dvh] items-center justify-center bg-background"><div className="font-mono-ui text-xs uppercase tracking-wider text-muted-foreground">Checking administrator session…</div></div>;
  if (!supabase || !profile || error) return <SignInScreen message={error} onRetry={() => setRefresh((value) => value + 1)} />;
  return <>{children}</>;
}

function Header({ onMenu }: { onMenu: () => void }) {
  const [location] = useLocation();
  const current = navItems.find((item) => item.href === location)?.label ?? (location === '/settings' ? 'Settings' : 'Admin console');
  return (
    <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between border-b border-border/80 bg-background/95 px-5 backdrop-blur-md lg:px-8">
      <div className="flex items-center gap-3">
        <button className="rounded-lg p-2 text-muted-foreground hover:bg-muted lg:hidden" onClick={onMenu} aria-label="Open navigation" data-testid="button-open-navigation">
          <Menu size={20} />
        </button>
        <div>
          <p className="font-mono-ui text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Operations / {current}</p>
          <h1 className="font-display text-xl font-semibold tracking-tight text-foreground lg:text-2xl">{current}</h1>
        </div>
      </div>
      <div className="hidden items-center gap-3 sm:flex">
        <div className="flex items-center gap-2 rounded-full border border-border bg-card px-3 py-2 text-xs text-muted-foreground">
          <span className="h-2 w-2 rounded-full bg-emerald-500" />
          Public site connected
        </div>
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">OM</div>
      </div>
    </header>
  );
}

function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [location] = useLocation();
  return (
    <>
      {open && <button className="fixed inset-0 z-30 bg-[hsl(155_32%_10%/.5)] lg:hidden" onClick={onClose} aria-label="Close navigation" data-testid="button-close-navigation" />}
      <aside className={cn('fixed inset-y-0 left-0 z-40 flex w-[260px] flex-col bg-sidebar text-sidebar-foreground transition-transform duration-300 lg:translate-x-0', open ? 'translate-x-0' : '-translate-x-full')}>
        <div className="flex h-[104px] items-center border-b border-sidebar-border px-7">
          <div className="mr-3 flex h-11 w-11 items-center justify-center rounded-xl border border-sidebar-primary/50 bg-sidebar-primary/10 text-sidebar-primary">
            <span className="font-display text-2xl font-bold">O</span>
          </div>
          <div>
            <p className="font-display text-[21px] font-semibold leading-none text-sidebar-foreground">Our Masjid</p>
            <p className="mt-1 font-mono-ui text-[9px] uppercase tracking-[0.22em] text-sidebar-foreground/55">Admin console</p>
          </div>
          <button className="ml-auto rounded-md p-1.5 text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-foreground lg:hidden" onClick={onClose} aria-label="Close menu" data-testid="button-sidebar-close"><PanelLeftClose size={17} /></button>
        </div>
        <div className="px-4 py-7">
          <p className="px-3 pb-3 font-mono-ui text-[10px] uppercase tracking-[0.18em] text-sidebar-foreground/45">Workspace</p>
          <nav className="space-y-1" aria-label="Primary navigation">
            {navItems.map((item) => {
              const active = item.href === location;
              const Icon = item.icon;
              return (
                <Link href={item.href} onClick={onClose} key={item.href} className={cn('group flex items-center gap-3 rounded-lg px-3 py-3 text-sm transition-colors', active ? 'bg-sidebar-accent font-semibold text-sidebar-primary' : 'text-sidebar-foreground/70 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground')} data-testid={`link-nav-${item.label.toLowerCase().replaceAll(' ', '-')}`}>
                  <Icon size={17} strokeWidth={active ? 2.4 : 1.8} />
                  <span>{item.label}</span>
                  {active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-sidebar-primary" />}
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="mt-auto p-4">
          <div className="rounded-xl border border-sidebar-border bg-sidebar-accent/40 p-4">
            <div className="flex items-center gap-2 text-sidebar-primary"><ShieldCheck size={16} /><span className="font-mono-ui text-[10px] uppercase tracking-[0.12em]">Trusted workspace</span></div>
            <p className="mt-2 text-xs leading-relaxed text-sidebar-foreground/60">Verified information only. Every published figure is visible to the community.</p>
          </div>
          <Link href="/settings" onClick={onClose} className={cn('mt-3 flex items-center gap-3 rounded-lg px-3 py-3 text-sm transition-colors', location === '/settings' ? 'bg-sidebar-accent text-sidebar-primary' : 'text-sidebar-foreground/65 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground')} data-testid="link-nav-settings"><Settings2 size={17} /><span>Settings</span></Link>
        </div>
      </aside>
    </>
  );
}

function Shell({ children }: { children: ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  return (
    <div className="min-h-[100dvh] bg-background">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="lg:pl-[260px]">
        <Header onMenu={() => setSidebarOpen(true)} />
        <main className="mx-auto max-w-[1500px] px-5 py-7 lg:px-8 lg:py-9">{children}</main>
      </div>
    </div>
  );
}

function SkeletonBlock({ className }: { className?: string }) {
  return <div className={cn('shimmer rounded-lg', className)} />;
}

function QueryState({ loading, error, empty, onRetry, children, label }: { loading: boolean; error: unknown; empty?: boolean; onRetry: () => void; children: ReactNode; label: string }) {
  if (loading) return <div className="space-y-3" aria-label={`Loading ${label}`} data-testid={`loading-${label}`}><SkeletonBlock className="h-24 w-full" /><SkeletonBlock className="h-24 w-full" /><SkeletonBlock className="h-24 w-full" /></div>;
  if (error) return <div className="flex flex-col items-center justify-center rounded-xl border border-destructive/25 bg-destructive/5 px-6 py-14 text-center" data-testid={`error-${label}`}><div className="mb-3 rounded-full bg-destructive/10 p-3 text-destructive"><AlertTriangle size={21} /></div><h3 className="font-display text-xl font-semibold">Couldn’t load {label}</h3><p className="mt-1 max-w-sm text-sm text-muted-foreground">The public content service did not respond. Nothing has been changed.</p><button onClick={onRetry} className="mt-5 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground" data-testid={`button-retry-${label}`}><RefreshCw size={15} /> Try again</button></div>;
  if (empty) return <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border bg-card/60 px-6 py-16 text-center" data-testid={`empty-${label}`}><div className="mb-3 rounded-full bg-secondary p-3 text-secondary-foreground"><LibraryBig size={21} /></div><h3 className="font-display text-xl font-semibold">No {label} match this view</h3><p className="mt-1 max-w-sm text-sm text-muted-foreground">Try clearing the filters or check back after the next publication review.</p></div>;
  return <>{children}</>;
}

function SectionHeading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: ReactNode }) {
  return <div className="mb-7 flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="font-mono-ui text-[10px] uppercase tracking-[0.2em] text-primary">{eyebrow}</p><h2 className="mt-1 font-display text-3xl font-semibold tracking-tight text-foreground">{title}</h2>{description && <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{description}</p>}</div>{action}</div>;
}

function MetricCard({ label, value, detail, icon: Icon, accent = 'green' }: { label: string; value: string; detail: string; icon: typeof Activity; accent?: 'green' | 'gold' | 'red' }) {
  return <div className="group rounded-xl border border-border bg-card p-5 shadow-[0_2px_0_hsl(var(--foreground)/.03)] transition-transform duration-200 hover:-translate-y-0.5" data-testid={`metric-${label.toLowerCase().replaceAll(' ', '-')}`}><div className="flex items-start justify-between"><p className="font-mono-ui text-[10px] uppercase tracking-[0.16em] text-muted-foreground">{label}</p><div className={cn('rounded-lg p-2', accent === 'green' ? 'bg-secondary text-primary' : accent === 'gold' ? 'bg-accent/25 text-[hsl(38_56%_40%)]' : 'bg-destructive/10 text-destructive')}><Icon size={16} /></div></div><p className="mt-5 font-display text-3xl font-semibold tracking-tight">{value}</p><p className="mt-1 text-xs text-muted-foreground">{detail}</p></div>;
}

function Overview() {
  const projects = useListPublishedProjects({ query: { queryKey: apiKeys.projects } });
  const masjids = useListPublishedMasjids({ query: { queryKey: apiKeys.masjids } });
  const slides = useListPublishedHomeSlides({ query: { queryKey: apiKeys.slides } });
  const health = useHealthCheck({ query: { queryKey: apiKeys.health } });
  const projectData = (projects.data ?? []) as ProjectRecord[];
  const masjidData = masjids.data ?? [];
  const raised = projectData.reduce((sum, project) => sum + (project.raised_amount || 0), 0);
  const target = projectData.reduce((sum, project) => sum + (project.target_amount || 0), 0);
  const urgentMasjids = masjidData.filter((m) => m.is_urgent);
  const healthOk = !health.isError && health.data?.status;
  return <div className="page-enter">
    <div className="mb-8 flex flex-col gap-4 border-b border-border pb-7 md:flex-row md:items-end md:justify-between">
      <div><div className="mb-3 inline-flex items-center gap-2 rounded-full border border-accent/40 bg-accent/10 px-3 py-1.5 font-mono-ui text-[10px] uppercase tracking-[0.14em] text-[hsl(38_56%_40%)]"><Sparkles size={13} /> Publication desk</div><h2 className="font-display text-4xl font-semibold tracking-[-0.03em] sm:text-5xl">Good work, carefully shared.</h2><p className="mt-3 max-w-xl text-sm leading-relaxed text-muted-foreground">A clear view of what your community can see today — and whether the systems behind it are ready.</p></div>
      <div className="flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2.5 text-xs text-muted-foreground"><span className={cn('h-2 w-2 rounded-full', healthOk ? 'bg-emerald-500' : health.isLoading ? 'bg-amber-400' : 'bg-destructive')} />{health.isLoading ? 'Checking connection…' : healthOk ? `API healthy · ${health.data?.status}` : 'API needs attention'}</div>
    </div>
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <MetricCard label="Published masjids" value={masjids.isLoading ? '—' : String(masjidData.length)} detail={`${masjidData.filter((m) => m.is_featured).length} featured for discovery`} icon={Building2} />
      <MetricCard label="Active projects" value={projects.isLoading ? '—' : String(projectData.length)} detail={`${projectData.filter((p) => p.featured).length} currently featured`} icon={HeartHandshake} accent="gold" />
      <MetricCard label="Community raised" value={projects.isLoading ? '—' : formatMoney(raised)} detail={`${formatMoney(target)} total target across projects`} icon={WalletCards} />
      <MetricCard label="Home slides" value={slides.isLoading ? '—' : String(slides.data?.length ?? 0)} detail={healthOk ? 'Publishing service connected' : 'Connection status unknown'} icon={GalleryHorizontalEnd} accent={healthOk ? 'green' : 'red'} />
    </div>
    <div className="mt-8 grid gap-6 xl:grid-cols-[1.25fr_.75fr]">
      <div className="rounded-xl border border-border bg-card">
        <div className="flex items-center justify-between border-b border-border px-5 py-4"><div><p className="font-mono-ui text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Live register</p><h3 className="mt-1 font-display text-xl font-semibold">Recent public projects</h3></div><Link href="/projects" className="flex items-center gap-1 text-xs font-semibold text-primary hover:underline" data-testid="link-view-projects">View all <ArrowUpRight size={14} /></Link></div>
        <QueryState loading={projects.isLoading} error={projects.error} onRetry={() => projects.refetch()} empty={!projectData.length} label="projects"><div className="divide-y divide-border">{projectData.slice(0, 5).map((project) => <ProjectRow key={project.id} project={project} />)}</div></QueryState>
      </div>
      <div className="space-y-6">
        <div className="rounded-xl border border-border bg-card p-5"><div className="flex items-center gap-2"><div className="rounded-lg bg-destructive/10 p-2 text-destructive"><AlertTriangle size={17} /></div><div><p className="font-mono-ui text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Needs attention</p><h3 className="font-display text-xl font-semibold">Urgent masjids</h3></div></div>{masjids.isLoading ? <div className="mt-5 space-y-2"><SkeletonBlock className="h-12" /><SkeletonBlock className="h-12" /></div> : urgentMasjids.length ? <div className="mt-4 space-y-2">{urgentMasjids.slice(0, 4).map((masjid) => <div key={masjid.id} className="flex items-center justify-between rounded-lg bg-destructive/5 px-3 py-3"><div><p className="text-sm font-semibold">{masjid.name}</p><p className="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground"><MapPin size={12} />{masjid.city}</p></div><span className="font-mono-ui text-[10px] uppercase tracking-wider text-destructive">Urgent</span></div>)}</div> : <p className="mt-5 rounded-lg bg-secondary/70 px-3 py-4 text-sm text-muted-foreground">No urgent Masjids are currently published.</p>}<Link href="/masjids" className="mt-4 flex items-center gap-1 text-xs font-semibold text-primary" data-testid="link-review-masjids">Review Masjids <ChevronRight size={14} /></Link></div>
        <div className="rounded-xl border border-border bg-primary p-5 text-primary-foreground"><div className="flex items-center gap-2"><FileCheck2 size={18} /><p className="font-mono-ui text-[10px] uppercase tracking-[0.16em] opacity-75">Accountability note</p></div><p className="mt-4 font-display text-2xl leading-tight">Publish only what you can stand behind.</p><p className="mt-3 text-xs leading-relaxed opacity-75">This console reflects published records. Editing and approvals remain unavailable until the content management API is connected.</p></div>
      </div>
    </div>
  </div>;
}

function ProjectRow({ project }: { project: ProjectRecord }) {
  const progress = project.target_amount ? Math.min(100, Math.round((project.raised_amount / project.target_amount) * 100)) : 0;
  return <div className="flex items-center gap-4 px-5 py-4" data-testid={`row-project-${project.id}`}><div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary"><HeartHandshake size={18} /></div><div className="min-w-0 flex-1"><div className="flex items-center gap-2"><p className="truncate text-sm font-semibold">{project.title}</p>{project.featured && <span className="rounded-full bg-accent/20 px-2 py-0.5 font-mono-ui text-[9px] uppercase text-[hsl(38_56%_40%)]">Featured</span>}</div><p className="mt-1 truncate text-xs text-muted-foreground">{project.category?.name || 'Community initiative'} · {project.status}</p></div><div className="hidden w-32 sm:block"><div className="mb-1 flex justify-between font-mono-ui text-[9px] text-muted-foreground"><span>{progress}% funded</span><span>{formatMoney(project.raised_amount)}</span></div><div className="h-1.5 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary" style={{ width: `${progress}%` }} /></div></div><ChevronRight size={16} className="text-muted-foreground" /></div>;
}

function SearchBar({ value, onChange, placeholder }: { value: string; onChange: (value: string) => void; placeholder: string }) {
  return <div className="relative"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" /><input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="h-10 w-full rounded-lg border border-input bg-card pl-9 pr-9 text-sm outline-none transition-shadow placeholder:text-muted-foreground/70 focus:ring-2 focus:ring-ring/30" data-testid={`input-search-${placeholder.toLowerCase().replaceAll(' ', '-')}`} />{value && <button onClick={() => onChange('')} className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground hover:bg-muted" aria-label="Clear search" data-testid="button-clear-search"><X size={15} /></button>}</div>;
}

function FilterChip({ active, children, onClick, testId }: { active: boolean; children: ReactNode; onClick: () => void; testId: string }) {
  return <button onClick={onClick} className={cn('rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors', active ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground')} data-testid={testId}>{children}</button>;
}

function MasjidsPage() {
  const query = useListPublishedMasjids({ query: { queryKey: apiKeys.masjids } });
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'featured' | 'urgent'>('all');
  const data = query.data ?? [];
  const filtered = useMemo(() => data.filter((item) => `${item.name} ${item.city} ${item.location}`.toLowerCase().includes(search.toLowerCase())).filter((item) => filter === 'all' || (filter === 'featured' ? item.is_featured : item.is_urgent)), [data, filter, search]);
  return <div className="page-enter"><SectionHeading eyebrow="Public directory" title="Masjids" description="A verified register of the Masjids currently visible in the Our Masjid experience." action={<span className="font-mono-ui text-xs text-muted-foreground">{filtered.length} / {data.length} records</span>} /><div className="mb-5 flex flex-col gap-3 rounded-xl border border-border bg-card p-3 sm:flex-row"><div className="min-w-0 flex-1"><SearchBar value={search} onChange={setSearch} placeholder="Search by name or city" /></div><div className="flex items-center gap-2 overflow-x-auto"><Filter size={15} className="ml-1 shrink-0 text-muted-foreground" /><FilterChip active={filter === 'all'} onClick={() => setFilter('all')} testId="filter-masjids-all">All</FilterChip><FilterChip active={filter === 'featured'} onClick={() => setFilter('featured')} testId="filter-masjids-featured">Featured</FilterChip><FilterChip active={filter === 'urgent'} onClick={() => setFilter('urgent')} testId="filter-masjids-urgent">Urgent</FilterChip></div></div><QueryState loading={query.isLoading} error={query.error} empty={!filtered.length} onRetry={() => query.refetch()} label="masjids"><div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{filtered.map((masjid) => <MasjidCard key={masjid.id} masjid={masjid} />)}</div></QueryState></div>;
}

function MasjidCard({ masjid }: { masjid: PublicMasjid }) {
  return <article className="group overflow-hidden rounded-xl border border-border bg-card transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-md" data-testid={`card-masjid-${masjid.id}`}><div className="relative h-32 bg-secondary">{masjid.image_url ? <img src={masjid.image_url} alt="" className="h-full w-full object-cover" /> : <div className="flex h-full items-center justify-center text-primary/40"><Building2 size={42} strokeWidth={1} /></div>}<div className="absolute left-3 top-3 flex gap-2">{masjid.is_urgent && <span className="rounded-full bg-destructive px-2 py-1 font-mono-ui text-[9px] uppercase tracking-wider text-white">Urgent</span>}{masjid.is_featured && <span className="rounded-full bg-accent px-2 py-1 font-mono-ui text-[9px] uppercase tracking-wider text-accent-foreground">Featured</span>}</div></div><div className="p-4"><h3 className="font-display text-xl font-semibold">{masjid.name}</h3><p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground"><MapPin size={13} />{masjid.location}, {masjid.city}</p><p className="mt-3 line-clamp-2 text-sm leading-relaxed text-muted-foreground">{masjid.description || 'No public description has been provided.'}</p><div className="mt-4 flex items-center justify-between border-t border-border pt-3"><span className="font-mono-ui text-[10px] uppercase tracking-wider text-muted-foreground">Published record</span><span className="flex items-center gap-1 text-xs font-semibold text-primary"><Check size={14} /> Verified</span></div></div></article>;
}

function ProjectsPage() {
  const query = useListPublishedProjects({ query: { queryKey: apiKeys.projects } });
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'featured' | 'funded'>('all');
  const data = (query.data ?? []) as ProjectRecord[];
  const filtered = useMemo(() => data.filter((item) => `${item.title} ${item.short_description || ''} ${item.category?.name || ''}`.toLowerCase().includes(search.toLowerCase())).filter((item) => filter === 'all' || (filter === 'featured' ? item.featured : item.raised_amount >= item.target_amount)), [data, filter, search]);
  return <div className="page-enter"><SectionHeading eyebrow="Public fundraising" title="Projects" description="Published initiatives and the figures shared with the community." action={<span className="font-mono-ui text-xs text-muted-foreground">{filtered.length} / {data.length} records</span>} /><div className="mb-5 flex flex-col gap-3 rounded-xl border border-border bg-card p-3 sm:flex-row"><div className="min-w-0 flex-1"><SearchBar value={search} onChange={setSearch} placeholder="Search projects or categories" /></div><div className="flex items-center gap-2 overflow-x-auto"><Filter size={15} className="ml-1 shrink-0 text-muted-foreground" /><FilterChip active={filter === 'all'} onClick={() => setFilter('all')} testId="filter-projects-all">All</FilterChip><FilterChip active={filter === 'featured'} onClick={() => setFilter('featured')} testId="filter-projects-featured">Featured</FilterChip><FilterChip active={filter === 'funded'} onClick={() => setFilter('funded')} testId="filter-projects-funded">Target met</FilterChip></div></div><QueryState loading={query.isLoading} error={query.error} empty={!filtered.length} onRetry={() => query.refetch()} label="projects"><div className="overflow-hidden rounded-xl border border-border bg-card"><div className="hidden grid-cols-[1.4fr_.75fr_.65fr_.7fr] gap-4 border-b border-border bg-muted/50 px-5 py-3 font-mono-ui text-[10px] uppercase tracking-[0.14em] text-muted-foreground md:grid"><span>Project</span><span>Status</span><span>Progress</span><span className="text-right">Raised</span></div>{filtered.map((project) => <ProjectTableRow key={project.id} project={project} />)}</div></QueryState></div>;
}

function ProjectTableRow({ project }: { project: ProjectRecord }) {
  const progress = project.target_amount ? Math.min(100, Math.round((project.raised_amount / project.target_amount) * 100)) : 0;
  return <div className="grid gap-3 border-b border-border px-5 py-4 last:border-0 md:grid-cols-[1.4fr_.75fr_.65fr_.7fr] md:items-center md:gap-4" data-testid={`row-project-detail-${project.id}`}><div className="min-w-0"><div className="flex items-center gap-2"><p className="truncate text-sm font-semibold">{project.title}</p>{project.featured && <span className="hidden rounded-full bg-accent/20 px-2 py-0.5 font-mono-ui text-[9px] uppercase text-[hsl(38_56%_40%)] sm:inline">Featured</span>}</div><p className="mt-1 truncate text-xs text-muted-foreground">{project.category?.name || 'Community initiative'}{project.masjid?.name ? ` · ${project.masjid.name}` : ''}</p></div><div><span className={cn('rounded-full px-2 py-1 font-mono-ui text-[9px] uppercase tracking-wider', project.status.toLowerCase().includes('active') ? 'bg-secondary text-primary' : 'bg-muted text-muted-foreground')}>{project.status}</span></div><div className="flex items-center gap-2"><div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary" style={{ width: `${progress}%` }} /></div><span className="font-mono-ui text-[10px] text-muted-foreground">{progress}%</span></div><div className="flex items-baseline justify-between md:block md:text-right"><span className="text-xs text-muted-foreground md:hidden">Raised</span><span className="font-mono-ui text-xs font-semibold">{formatMoney(project.raised_amount)} <span className="font-normal text-muted-foreground">/ {formatMoney(project.target_amount)}</span></span></div></div>;
}

function SlidesPage() {
  const query = useListPublishedHomeSlides({ query: { queryKey: apiKeys.slides } });
  const data = query.data ?? [];
  return <div className="page-enter"><SectionHeading eyebrow="Homepage composition" title="Home slides" description="The current sequence of public messages shown on the Our Masjid home experience." action={<span className="font-mono-ui text-xs text-muted-foreground">{data.length} published slides</span>} /><QueryState loading={query.isLoading} error={query.error} empty={!data.length} onRetry={() => query.refetch()} label="slides"><div className="grid gap-5 lg:grid-cols-2">{data.map((slide, index) => <SlideCard key={slide.id} slide={slide} index={index} />)}</div></QueryState><div className="mt-7 flex items-start gap-3 rounded-xl border border-dashed border-border bg-card/60 p-4 text-sm text-muted-foreground"><CircleHelp size={17} className="mt-0.5 shrink-0 text-primary" /><p>Slide ordering and content edits are not configured in this console yet. This view is intentionally read-only so publication decisions remain traceable.</p></div></div>;
}

function SlideCard({ slide, index }: { slide: HomeSlide; index: number }) {
  return <article className="overflow-hidden rounded-xl border border-border bg-card" data-testid={`card-slide-${slide.id}`}><div className="relative aspect-[2.25/1] overflow-hidden bg-primary">{slide.image_url ? <img src={slide.image_url} alt="" className="h-full w-full object-cover opacity-80" /> : <div className="absolute inset-0 flex items-center justify-center text-primary-foreground/25"><GalleryHorizontalEnd size={65} strokeWidth={1} /></div>}<div className="absolute inset-0 bg-gradient-to-t from-[hsl(155_38%_12%/.82)] to-transparent" /><span className="absolute left-4 top-4 rounded-full bg-[hsl(42_30%_96%/.9)] px-2.5 py-1 font-mono-ui text-[10px] font-semibold text-primary">0{index + 1}</span><div className="absolute bottom-4 left-4 right-4 text-primary-foreground"><h3 className="font-display text-2xl font-semibold">{slide.title}</h3>{slide.subtitle && <p className="mt-1 line-clamp-1 text-sm opacity-80">{slide.subtitle}</p>}</div></div><div className="flex items-center justify-between px-4 py-3"><div className="flex items-center gap-2 text-xs text-muted-foreground"><FileCheck2 size={14} className="text-primary" />Published</div><span className="font-mono-ui text-[10px] uppercase tracking-wider text-muted-foreground">{slide.action_type || 'No action'}</span></div></article>;
}

function SettingsPage() {
  const health = useHealthCheck({ query: { queryKey: apiKeys.health } });
  const status = health.data?.status;
  return <div className="page-enter"><SectionHeading eyebrow="Workspace controls" title="Settings" description="Connection visibility and guardrails for the trusted publishing workspace." /><div className="grid gap-6 lg:grid-cols-[1.1fr_.9fr]"><div className="rounded-xl border border-border bg-card"><div className="border-b border-border px-5 py-4"><p className="font-mono-ui text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Connections</p><h3 className="mt-1 font-display text-xl font-semibold">Service health</h3></div><div className="divide-y divide-border"><ServiceRow label="Public content API" detail="Reads published Masjids, projects, and homepage slides" state={health.isLoading ? 'checking' : status ? 'healthy' : 'error'} /><ServiceRow label="Admin write operations" detail="Create, edit, approve, and archive records" state="unavailable" /><ServiceRow label="Evidence attachments" detail="Review source documents and verification notes" state="unavailable" /></div><div className="flex items-center justify-between border-t border-border bg-muted/30 px-5 py-4"><span className="font-mono-ui text-[10px] text-muted-foreground">Endpoint /api/healthz</span><button onClick={() => health.refetch()} className="flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-xs font-semibold hover:bg-muted" data-testid="button-refresh-health"><RefreshCw size={14} className={health.isFetching ? 'animate-spin' : ''} />Refresh</button></div></div><div className="space-y-6"><div className="rounded-xl border border-border bg-primary p-6 text-primary-foreground"><ShieldCheck size={22} className="text-accent" /><h3 className="mt-5 font-display text-2xl font-semibold">Trusted access</h3><p className="mt-2 text-sm leading-relaxed text-primary-foreground/70">This console is designed for verified administrators. Authentication and role provisioning are managed by the host environment.</p><div className="mt-6 flex items-center gap-2 border-t border-primary-foreground/15 pt-4 font-mono-ui text-[10px] uppercase tracking-wider text-primary-foreground/60"><Check size={14} className="text-accent" />Read access active</div></div><div className="rounded-xl border border-dashed border-border bg-card/60 p-5"><div className="flex items-center gap-2 text-muted-foreground"><PanelLeftOpen size={17} /><p className="font-mono-ui text-[10px] uppercase tracking-[0.16em]">Not configured</p></div><p className="mt-3 text-sm leading-relaxed text-muted-foreground">Write permissions, audit history, and evidence review will appear here when their API contracts are available. No placeholder actions are shown.</p></div></div></div></div>;
}

function ServiceRow({ label, detail, state }: { label: string; detail: string; state: 'healthy' | 'error' | 'checking' | 'unavailable' }) {
  const config = { healthy: { text: 'Healthy', cls: 'text-emerald-700 bg-emerald-500/10', dot: 'bg-emerald-500' }, error: { text: 'Unavailable', cls: 'text-destructive bg-destructive/10', dot: 'bg-destructive' }, checking: { text: 'Checking', cls: 'text-amber-700 bg-amber-500/10', dot: 'bg-amber-500' }, unavailable: { text: 'Not configured', cls: 'text-muted-foreground bg-muted', dot: 'bg-muted-foreground/50' } }[state];
  return <div className="flex items-center justify-between gap-4 px-5 py-4"><div><p className="text-sm font-semibold">{label}</p><p className="mt-1 text-xs text-muted-foreground">{detail}</p></div><span className={cn('flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1 font-mono-ui text-[9px] uppercase tracking-wider', config.cls)}><span className={cn('h-1.5 w-1.5 rounded-full', config.dot)} />{config.text}</span></div>;
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={Overview} /><Route path="/masjids" component={MasjidsPage} /><Route path="/projects" component={ProjectsPage} /><Route path="/slides" component={SlidesPage} /><Route path="/settings" component={SettingsPage} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><AdminGate><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Shell><Router /></Shell></WouterRouter></AdminGate><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;