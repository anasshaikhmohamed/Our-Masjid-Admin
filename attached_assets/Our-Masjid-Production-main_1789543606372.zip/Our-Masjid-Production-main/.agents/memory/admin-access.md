---
name: Admin access
description: Security boundary for the separate Our Masjid administration console
---

The admin console must fail closed: require a Supabase Auth session, then require a `profiles.role` of `admin` or `super_admin` before rendering operational content.

**Why:** Public content can be read without exposing private documents, fundraising controls, roles, or audit activity; an unauthenticated admin shell would undermine that separation.

**How to apply:** Keep missing `VITE_SUPABASE_URL` or `VITE_SUPABASE_ANON_KEY` as an explicit setup state, never as a demo session or fallback administrator.