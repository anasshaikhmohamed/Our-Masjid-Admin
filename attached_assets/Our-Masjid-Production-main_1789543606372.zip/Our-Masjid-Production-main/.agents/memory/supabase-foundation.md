---
name: Supabase foundation
description: External Supabase schema application constraint for the Our Masjid project
---

The Our Masjid foundation migration is prepared in the repository, but the attached Supabase connector only exposes REST-style access in this workspace. Applying the migration requires a SQL-capable Supabase workflow.

**Why:** The REST check returned a missing `public.profiles` relation, so treating the schema as applied would make the mobile fallback and API error states misleading.

**How to apply:** Keep the app tolerant of an unconfigured or not-yet-migrated Supabase project. Once the migration is applied, verify the public read endpoints and RLS policies before enabling live content.